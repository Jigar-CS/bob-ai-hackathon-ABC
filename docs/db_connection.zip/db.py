"""MySQL connection layer for PortPulse, using SQLAlchemy + PyMySQL.
Reads connection settings from environment variables (.env)."""
from __future__ import annotations

import os
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import datetime

DB_USER = os.getenv("MYSQL_USER", "root")
DB_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
DB_HOST = os.getenv("MYSQL_HOST", "127.0.0.1")
DB_PORT = os.getenv("MYSQL_PORT", "3306")
DB_NAME = os.getenv("MYSQL_DATABASE", "portpulse")

DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class PredictionLog(Base):
    __tablename__ = "prediction_log"

    id = Column(Integer, primary_key=True, autoincrement=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    vessel_id = Column(String(20))
    window_day = Column(Integer)
    vessel_count = Column(Integer)
    incoming_teu = Column(Integer)
    total_capacity_teu = Column(Integer)
    utilization_ratio = Column(Float)
    predicted_risk_level = Column(String(10))
    predicted_wait_hours = Column(Float)
    actual_wait_hours = Column(Float, nullable=True)
    actual_risk_level = Column(String(10), nullable=True)
    model_version = Column(String(20))


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def check_connection() -> bool:
    try:
        with engine.connect() as conn:
            conn.exec_driver_sql("SELECT 1")
        return True
    except Exception:
        return False
