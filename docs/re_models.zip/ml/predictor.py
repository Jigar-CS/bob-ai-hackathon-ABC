"""Unified ML predictor for PortPulse.

Loads all 6 trained models once and exposes one function per prediction task.
Every function returns None on any failure (missing file, bad input, load
error) so callers can fall back to the existing rule-based/heuristic logic
without ever raising — matching the project's existing resilient-fallback
pattern used for watsonx.ai.

Optional: logs each risk/wait prediction to the `prediction_log` MySQL table
via db.py, if the DB is reachable. Logging failures never affect the caller.
"""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)
_MODEL_DIR = Path(__file__).parent

_risk_model = None
_risk_encoder = None
_wait_model = None
_demurrage_model = None
_crane_model = None
_anomaly_model = None
_load_attempted = False


def _load() -> None:
    global _risk_model, _risk_encoder, _wait_model
    global _demurrage_model, _crane_model, _anomaly_model, _load_attempted
    if _load_attempted:
        return
    _load_attempted = True
    try:
        import joblib
        _risk_model = joblib.load(_MODEL_DIR / "risk_model.pkl")
        _risk_encoder = joblib.load(_MODEL_DIR / "risk_label_encoder.pkl")
        _wait_model = joblib.load(_MODEL_DIR / "wait_model.pkl")
        _demurrage_model = joblib.load(_MODEL_DIR / "demurrage_model.pkl")
        _crane_model = joblib.load(_MODEL_DIR / "crane_productivity_model.pkl")
        _anomaly_model = joblib.load(_MODEL_DIR / "anomaly_model.pkl")
        logger.info("All 6 ML models loaded from %s", _MODEL_DIR)
    except Exception as err:  # noqa: BLE001
        logger.warning("Could not load one or more ML models: %s", err)


# ---------------------------------------------------------------------------
# Congestion risk classifier
# ---------------------------------------------------------------------------
def predict_risk(features: dict[str, Any]) -> str | None:
    """features: vessel_count, incoming_teu, total_capacity_teu, day_index, utilization_ratio"""
    _load()
    if _risk_model is None or _risk_encoder is None:
        return None
    try:
        row = [[
            features["vessel_count"],
            features["incoming_teu"],
            features["total_capacity_teu"],
            features["day_index"],
            features["utilization_ratio"],
        ]]
        pred = _risk_model.predict(row)
        return str(_risk_encoder.inverse_transform(pred)[0])
    except Exception as err:  # noqa: BLE001
        logger.warning("ML risk prediction failed: %s", err)
        return None


# ---------------------------------------------------------------------------
# Vessel wait-time regressor
# ---------------------------------------------------------------------------
def predict_wait(features: dict[str, Any]) -> float | None:
    """features: size_teu, priority, crane_count, berth_capacity_teu, n_berths, n_vessels"""
    _load()
    if _wait_model is None:
        return None
    try:
        row = [[
            features["size_teu"],
            features["priority"],
            features["crane_count"],
            features["berth_capacity_teu"],
            features["n_berths"],
            features["n_vessels"],
        ]]
        return float(_wait_model.predict(row)[0])
    except Exception as err:  # noqa: BLE001
        logger.warning("ML wait prediction failed: %s", err)
        return None


# ---------------------------------------------------------------------------
# Demurrage cost regressor
# ---------------------------------------------------------------------------
def predict_demurrage_cost(features: dict[str, Any]) -> float | None:
    """features: wait_hours, priority, size_teu, cargo_type_hazmat (0/1)"""
    _load()
    if _demurrage_model is None:
        return None
    try:
        row = [[
            features["wait_hours"],
            features["priority"],
            features["size_teu"],
            features["cargo_type_hazmat"],
        ]]
        return float(_demurrage_model.predict(row)[0])
    except Exception as err:  # noqa: BLE001
        logger.warning("Demurrage prediction failed: %s", err)
        return None


# ---------------------------------------------------------------------------
# Crane productivity regressor
# ---------------------------------------------------------------------------
def predict_crane_productivity(features: dict[str, Any]) -> float | None:
    """features: crane_count, size_teu, priority, berth_capacity_teu"""
    _load()
    if _crane_model is None:
        return None
    try:
        row = [[
            features["crane_count"],
            features["size_teu"],
            features["priority"],
            features["berth_capacity_teu"],
        ]]
        return float(_crane_model.predict(row)[0])
    except Exception as err:  # noqa: BLE001
        logger.warning("Crane productivity prediction failed: %s", err)
        return None


# ---------------------------------------------------------------------------
# Anomaly detector
# ---------------------------------------------------------------------------
def is_anomalous(features: dict[str, Any]) -> bool | None:
    """features: size_teu, effective_dwell_hours, wait_hours, crane_count, priority"""
    _load()
    if _anomaly_model is None:
        return None
    try:
        row = [[
            features["size_teu"],
            features["effective_dwell_hours"],
            features["wait_hours"],
            features["crane_count"],
            features["priority"],
        ]]
        pred = _anomaly_model.predict(row)[0]  # -1 anomaly, 1 normal
        return bool(pred == -1)
    except Exception as err:  # noqa: BLE001
        logger.warning("Anomaly prediction failed: %s", err)
        return None


# ---------------------------------------------------------------------------
# Optional: log a risk/wait prediction row to MySQL (prediction_log table)
# ---------------------------------------------------------------------------
def log_prediction(
    vessel_id: str,
    window_day: int,
    vessel_count: int,
    incoming_teu: int,
    total_capacity_teu: int,
    utilization_ratio: float,
    predicted_risk_level: str | None,
    predicted_wait_hours: float | None,
    model_version: str = "v1",
) -> None:
    """Best-effort insert into prediction_log. Never raises."""
    try:
        from portpulse.db import SessionLocal, PredictionLog

        db = SessionLocal()
        try:
            entry = PredictionLog(
                created_at=datetime.utcnow(),
                vessel_id=vessel_id,
                window_day=window_day,
                vessel_count=vessel_count,
                incoming_teu=incoming_teu,
                total_capacity_teu=total_capacity_teu,
                utilization_ratio=utilization_ratio,
                predicted_risk_level=predicted_risk_level,
                predicted_wait_hours=predicted_wait_hours,
                model_version=model_version,
            )
            db.add(entry)
            db.commit()
        finally:
            db.close()
    except Exception as err:  # noqa: BLE001
        logger.warning("Could not log prediction to DB: %s", err)
